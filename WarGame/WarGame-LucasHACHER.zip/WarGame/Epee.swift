//
//  Epee.swift
//  WarGame
//
//  Created by Lucas HACHER on 09/10/2018.
//  Copyright © 2018 Lucas HACHER. All rights reserved.
//

import Foundation


class Epee: Arme {
    init() {
        super.init(degats: 10)
    }
}
