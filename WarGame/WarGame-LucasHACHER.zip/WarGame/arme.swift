//
//  Arme.swift
//  WarGame
//
//  Created by Lucas HACHER on 09/10/2018.
//  Copyright © 2018 Lucas HACHER. All rights reserved.
//

import Foundation

class Arme {
    
    var degats: Int
    
    
    init(degats: Int) {
        self.degats = degats
        
    }
    
    
}
